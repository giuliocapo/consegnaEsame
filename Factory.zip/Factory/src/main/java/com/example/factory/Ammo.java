package com.example.factory;

public class Ammo {
    String calibro;
    String colour;
    String rage;

    public String getCalibro() {
        return calibro;
    }

    public void setCalibro(String calibro) {
        this.calibro = calibro;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getRage() {
        return rage;
    }

    public void setRage(String rage) {
        this.rage = rage;
    }


}
